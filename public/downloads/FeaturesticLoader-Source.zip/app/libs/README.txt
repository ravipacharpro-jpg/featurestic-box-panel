FeaturesticBox SDK (.aar)
===========================

This directory contains the FeaturesticBox virtual container core SDK library (`FeaturesticBox.aar`).

1. The build automatically includes all .aar and .jar files located in this directory via:
   implementation fileTree(dir: "libs", include: ["*.jar", "*.aar"])

2. To update to the latest SDK version:
   Download the latest FeaturesticBox.aar from your Panel's Beta page and replace the file in this directory.
