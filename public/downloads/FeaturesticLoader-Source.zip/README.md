# Featurestic Loader - Android Project Template

A lightweight, high-performance Android virtual container loader powered by the **FeaturesticBox SDK**.

---

## 🚀 Quick Setup (3 Steps)

### 1. Set Your Panel Authentication URL
Open:
`app/src/main/java/com/bgmi/net/AuthApi.java`

Update the following constants:
```java
public static final String AUTH_URL = "https://ADD_YOUR_PANEL_URL.onrender.com/connect";
public static final String AUTH_SALT = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";
public static final String GAME = "PUBG"; // e.g. PUBG, BGMI, FREEFIRE
```

---

### 2. Configure Telegram / Support Link
Open:
`app/src/main/java/com/bgmi/ui/LoginActivity.java`

Update:
```java
private static final String GET_KEY_URL = "https://t.me/ADD_YOUR_TELEGRAM";
```

---

### 3. Build the Loader APK

#### In Android Studio:
1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

#### In Terminal / CLI:
```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease
```
The output APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📦 SDK Library (.aar)
The core container SDK is located in:
`app/libs/FeaturesticBox.aar`

Whenever an updated SDK version is released, download the latest `.aar` from your panel and drop it into `app/libs/`.
